#!/bin/bash
cd /var/app/current
echo "Setup script running..."
