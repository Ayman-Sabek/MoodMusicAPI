# MoodMusicAPI
An API to analyze the emotional tone of music and provide mood-based recommendations.
