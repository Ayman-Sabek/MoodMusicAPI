from flask import Flask, request, jsonify
import joblib
import os
import logging

app = Flask(__name__)

# Set up logging
logging.basicConfig(level=logging.INFO)

# Load models
try:
    rf_model = joblib.load('best_random_forest_model.pkl')
    knn_model = joblib.load('best_knn_model.pkl')
    svm_model = joblib.load('best_svm_model.pkl')
    logging.info("Models loaded successfully.")
except FileNotFoundError as e:
    logging.error(f"Error loading models: {e}")
    raise e

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        features = [
            data.get('energy', 0),
            data.get('valence', 0),
            data.get('tempo', 0),
            data.get('danceability', 0),
            data.get('mood_score', 0),
            data.get('log_tempo', 0),
            data.get('energy_danceability', 0)
        ]
        
        rf_prediction = rf_model.predict([features])[0]
        knn_prediction = knn_model.predict([features])[0]
        svm_prediction = svm_model.predict([features])[0]

        return jsonify({
            'Random Forest': rf_prediction,
            'K-Nearest Neighbors': knn_prediction,
            'Support Vector Machine': svm_prediction
        })
    except NotFittedError as e:
        logging.error(f"Model not fitted: {e}")
        return jsonify({'error': 'Model not fitted properly'}), 500
    except Exception as e:
        logging.error(f"Error during prediction: {e}")
        return jsonify({'error': 'An error occurred during prediction'}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8080)
